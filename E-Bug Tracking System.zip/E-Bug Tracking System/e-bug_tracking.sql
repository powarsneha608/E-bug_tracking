-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 01, 2023 at 10:20 AM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `e-bug_tracking`
--

-- --------------------------------------------------------

--
-- Table structure for table `add_bug`
--

CREATE TABLE `add_bug` (
  `BID` int(11) NOT NULL,
  `Bug` varchar(200) NOT NULL,
  `Severity` varchar(50) NOT NULL,
  `Project_ID` int(11) NOT NULL,
  `Project_Name` varchar(50) NOT NULL,
  `Description` varchar(200) NOT NULL,
  `DID` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `add_bug`
--

INSERT INTO `add_bug` (`BID`, `Bug`, `Severity`, `Project_ID`, `Project_Name`, `Description`, `DID`) VALUES
(1, 'runtime error', 'High', 1, 'bug tracking', 'hjhgvfgh', 1),
(2, 'compile time error', 'High', 2, 'E Farming', 'khjgjf', 2);

-- --------------------------------------------------------

--
-- Table structure for table `add_developer`
--

CREATE TABLE `add_developer` (
  `DID` int(11) NOT NULL,
  `DName` varchar(50) NOT NULL,
  `Image` varchar(500) NOT NULL,
  `Address` varchar(50) NOT NULL,
  `Contact` bigint(10) NOT NULL,
  `Email` varchar(50) NOT NULL,
  `Company_Name` varchar(50) NOT NULL,
  `Username` varchar(20) NOT NULL,
  `Password` varchar(16) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `add_developer`
--

INSERT INTO `add_developer` (`DID`, `DName`, `Image`, `Address`, `Contact`, `Email`, `Company_Name`, `Username`, `Password`) VALUES
(1, 'Ram Patil', '', 'Kolhapur', 9587958648, 'ram@gmail.com', 'Cisco', 'ram', '12345678'),
(2, 'Jay Patil', '', 'Kolhapur', 9587958648, 'jay12@gmail.com', 'KPIT', 'jay', '12345678');

-- --------------------------------------------------------

--
-- Table structure for table `add_manager`
--

CREATE TABLE `add_manager` (
  `MID` int(11) NOT NULL,
  `MName` varchar(50) NOT NULL,
  `Image` varchar(500) NOT NULL,
  `Address` varchar(50) NOT NULL,
  `Contact` bigint(10) NOT NULL,
  `Email` varchar(50) NOT NULL,
  `Company_Name` varchar(50) NOT NULL,
  `Username` varchar(20) NOT NULL,
  `Password` varchar(16) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `add_manager`
--

INSERT INTO `add_manager` (`MID`, `MName`, `Image`, `Address`, `Contact`, `Email`, `Company_Name`, `Username`, `Password`) VALUES
(1, 'Madhuri Chougale', '1000_F_443047509_axaKT1Zb5k0RsLKchFbC5Dre15stLwoD.jpg', 'Ajara', 8659745962, 'madhurichougale4@gmail.com', 'Cisco', 'madhuri', '12345678'),
(2, 'Sham Patil', '1000_F_443047509_axaKT1Zb5k0RsLKchFbC5Dre15stLwoD.jpg', 'Ajara', 8659745962, 'sham@gmail.com', 'Cisco', 'madhuri', '12345678');

-- --------------------------------------------------------

--
-- Table structure for table `add_project`
--

CREATE TABLE `add_project` (
  `Project_ID` int(11) NOT NULL,
  `Project_Name` varchar(50) NOT NULL,
  `Description` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `add_project`
--

INSERT INTO `add_project` (`Project_ID`, `Project_Name`, `Description`) VALUES
(1, 'bug tracking', 'hghbh'),
(2, 'E Farming', 'ghkgbg');

-- --------------------------------------------------------

--
-- Table structure for table `add_tester`
--

CREATE TABLE `add_tester` (
  `TID` int(11) NOT NULL,
  `TName` varchar(50) NOT NULL,
  `Image` varchar(500) NOT NULL,
  `Address` varchar(50) NOT NULL,
  `Contact` bigint(10) NOT NULL,
  `Email` varchar(50) NOT NULL,
  `Company_Name` varchar(50) NOT NULL,
  `Username` varchar(20) NOT NULL,
  `Password` varchar(16) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `add_tester`
--

INSERT INTO `add_tester` (`TID`, `TName`, `Image`, `Address`, `Contact`, `Email`, `Company_Name`, `Username`, `Password`) VALUES
(1, 'Sham Patil', '', 'Gadhinglaj', 8659745962, 'sham@gmail.com', 'Cisco', 'sham', '12345678'),
(2, 'Ram Patil', '', 'Gadhinglaj', 8659745962, 'ram@gmail.com', 'Cisco', 'sham', '12345678');

-- --------------------------------------------------------

--
-- Table structure for table `admin_signup`
--

CREATE TABLE `admin_signup` (
  `AID` int(11) NOT NULL,
  `AName` varchar(50) NOT NULL,
  `Image` varchar(500) NOT NULL,
  `Address` varchar(50) NOT NULL,
  `Email` varchar(50) NOT NULL,
  `Contact` bigint(10) NOT NULL,
  `Company_Name` varchar(50) NOT NULL,
  `Username` varchar(50) NOT NULL,
  `Password` varchar(16) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `aforgot_password`
--

CREATE TABLE `aforgot_password` (
  `Username` varchar(20) NOT NULL,
  `Password` varchar(16) NOT NULL,
  `Confirm_Password` varchar(16) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `assign_mproject`
--

CREATE TABLE `assign_mproject` (
  `WID` int(11) NOT NULL,
  `MID` int(11) NOT NULL,
  `Project_ID` int(11) NOT NULL,
  `Project_Name` varchar(50) NOT NULL,
  `Description` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `assign_mproject`
--

INSERT INTO `assign_mproject` (`WID`, `MID`, `Project_ID`, `Project_Name`, `Description`) VALUES
(1, 1, 1, 'bug tracking', 'hgfgfu'),
(2, 2, 2, 'E Farming', 'kghgu');

-- --------------------------------------------------------

--
-- Table structure for table `assign_tproject`
--

CREATE TABLE `assign_tproject` (
  `WID` int(11) NOT NULL,
  `TID` int(11) NOT NULL,
  `Project_ID` int(11) NOT NULL,
  `Project_Name` varchar(50) NOT NULL,
  `Description` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `assign_tproject`
--

INSERT INTO `assign_tproject` (`WID`, `TID`, `Project_ID`, `Project_Name`, `Description`) VALUES
(1, 1, 1, 'bug tracking', 'hfjhfjtu'),
(2, 2, 2, 'E Farming', 'kuhjubg');

-- --------------------------------------------------------

--
-- Table structure for table `bug_solution`
--

CREATE TABLE `bug_solution` (
  `Solution_ID` int(11) NOT NULL,
  `BID` int(11) NOT NULL,
  `Bug` varchar(200) NOT NULL,
  `Severity` varchar(50) NOT NULL,
  `Project_ID` int(11) NOT NULL,
  `Project_Name` varchar(50) NOT NULL,
  `Description` varchar(200) NOT NULL,
  `Bug_Solution` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `bug_solution`
--

INSERT INTO `bug_solution` (`Solution_ID`, `BID`, `Bug`, `Severity`, `Project_ID`, `Project_Name`, `Description`, `Bug_Solution`) VALUES
(1, 1, 'runtime error', 'High', 1, 'bug tracking', 'gbnjmbm ', 'hvbhgn'),
(2, 2, 'compile time error', 'High', 2, 'E Farming', 'hyuh', 'ghghj');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `add_bug`
--
ALTER TABLE `add_bug`
  ADD PRIMARY KEY (`BID`);

--
-- Indexes for table `add_developer`
--
ALTER TABLE `add_developer`
  ADD PRIMARY KEY (`DID`);

--
-- Indexes for table `add_manager`
--
ALTER TABLE `add_manager`
  ADD PRIMARY KEY (`MID`);

--
-- Indexes for table `add_project`
--
ALTER TABLE `add_project`
  ADD PRIMARY KEY (`Project_ID`);

--
-- Indexes for table `add_tester`
--
ALTER TABLE `add_tester`
  ADD PRIMARY KEY (`TID`);

--
-- Indexes for table `admin_signup`
--
ALTER TABLE `admin_signup`
  ADD PRIMARY KEY (`AID`);

--
-- Indexes for table `assign_mproject`
--
ALTER TABLE `assign_mproject`
  ADD PRIMARY KEY (`WID`);

--
-- Indexes for table `assign_tproject`
--
ALTER TABLE `assign_tproject`
  ADD PRIMARY KEY (`WID`);

--
-- Indexes for table `bug_solution`
--
ALTER TABLE `bug_solution`
  ADD PRIMARY KEY (`Solution_ID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `add_bug`
--
ALTER TABLE `add_bug`
  MODIFY `BID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `add_developer`
--
ALTER TABLE `add_developer`
  MODIFY `DID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `add_manager`
--
ALTER TABLE `add_manager`
  MODIFY `MID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `add_project`
--
ALTER TABLE `add_project`
  MODIFY `Project_ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `add_tester`
--
ALTER TABLE `add_tester`
  MODIFY `TID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `admin_signup`
--
ALTER TABLE `admin_signup`
  MODIFY `AID` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `assign_mproject`
--
ALTER TABLE `assign_mproject`
  MODIFY `WID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `assign_tproject`
--
ALTER TABLE `assign_tproject`
  MODIFY `WID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `bug_solution`
--
ALTER TABLE `bug_solution`
  MODIFY `Solution_ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
